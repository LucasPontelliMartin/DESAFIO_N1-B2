var express = require('express')
var app = express()

app.get('/', function (req, res) {
  res.send('Para o funcionamento correto da API insira a seguinte URL:  "  http://127.0.0.1:8000/ValorN=valueN/ValorM=valueM  " Onde: valueN = Valor de N Inteiro maior que 0; valueM = Valor de M Inteiro maior que 0');

})

app.get('/ValorN=:valorN/ValorM=:valorM', function (req, res) {
    let n = parseInt(req.params.valorN);
    let m = parseInt(req.params.valorM);
    var vetor = [];
    let auxiliar = 0;
    var resultado = 1;
    if(n < 1)
        res.json({Mensagem: "O Valor de N precisa ser maior que 0"});

    if(m < 1)
        res.json({Mensagem: "O Valor de M precisa ser maior que 0"});


    for( i = 0; i < n; i++){
        auxiliar = m + i;
        let valor = 0;

        valor = auxiliar + ( 1/ auxiliar)

        vetor.push(valor);

    }

    vetor.forEach(element => {
        resultado = resultado * element;
    });

    res.json({Resultado: resultado});


  })

app.listen(8000, function () {
  console.log('Example app listening on port 8000!')
})